{
    'name': 'Currency Rate Update Extension',
    'version': '14.0.1.0',
    'category': '',
    'summary': 'Agrega Banco de México como fuente para actualizar moneda',
    'author': 'IT Admin',
    'license': 'AGPL-3',
    'installable': True,
    'application': False,
    'depends': [
        'currency_rate_update',
    ],
    'data': [],
}
