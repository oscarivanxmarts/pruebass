# -*- coding: utf-8 -*-

from . import res_currency_rate_provider_MX_BdM
